<!DOCTYPE html>
<html lang="en-US">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>OceanVPN Panel Installer</title>
</head>

<form name="bonveio" action="<?php echo $URI; ?>" method="POST">

  <input type="hidden" name="DB_HOST" value="localhost" />
  <input type="hidden" name="DB_NAME" value="OCSPANEL" />
  <input type="hidden" name="DB_USER" value="root" />
  <input type="hidden" name="DB_PASS" value="haiqalqaz12" />
  <input type="hidden" name="username" value="admin" />
  <input type="hidden" name="email" value="admin@kingkongvpn.xyz" />
  <input type="hidden" name="password" value="haiqalqaz12" />
  <input type="hidden" name="password_confirmation" value="haiqalqaz12" />

</form>

<script type="text/javascript">
 document.bonveio.submit();
</script>

</html>
