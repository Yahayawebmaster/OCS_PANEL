<?php die();
[globals]
DEBUG=0
AUTOLOAD="controller/;model/"
UI="view/"
APP_KEY="30ec311a94f05d927b6d543adb803e04359c6bb954ea14cd65ff22c5fc5086d8"
DB_SET="mysql:host=localhost;port=3306;dbname=OCSPANEL"
DB_USER="root"
DB_PASS="haiqalqaz12"
?>